// controller.js

const data = require("./data");

// Melihat Data
function lihatData() {
  console.log("===== Data Saat Ini =====");
  data.map((item, index) => {
    console.log(
      `${index + 1}. Nama: ${item.nama}, Umur: ${item.umur}, Alamat: ${
        item.alamat
      }, Email: ${item.email}`
    );
  });
}

// Menambah Data
function tambahData() {
  const dataBaru = [
    {
      nama: "Kiki",
      umur: 23,
      alamat: "Banjarmasin",
      email: "kiki@example.com",
    },
    { nama: "Lala", umur: 21, alamat: "Kupang", email: "lala@example.com" },
  ];

  data.push(...dataBaru);
  console.log("\n✅ Data berhasil ditambahkan!\n");
}

// Menghapus Data berdasarkan nama
function hapusData(nama) {
  const index = data.findIndex(
    (item) => item.nama.toLowerCase() === nama.toLowerCase()
  );
  if (index !== -1) {
    data.splice(index, 1);
    console.log(`\n🗑️ Data dengan nama '${nama}' berhasil dihapus.\n`);
  } else {
    console.log(`\n❌ Data dengan nama '${nama}' tidak ditemukan.\n`);
  }
}

// Contoh pemanggilan fungsi
lihatData();
tambahData();
lihatData();
hapusData("Budi");
lihatData();
