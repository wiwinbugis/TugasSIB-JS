// data.js

const data = [
  { nama: "Andi", umur: 25, alamat: "Jakarta", email: "andi@example.com" },
  { nama: "Budi", umur: 30, alamat: "Bandung", email: "budi@example.com" },
  { nama: "Citra", umur: 22, alamat: "Surabaya", email: "citra@example.com" },
  { nama: "Dedi", umur: 28, alamat: "Yogyakarta", email: "dedi@example.com" },
  { nama: "Eka", umur: 27, alamat: "Semarang", email: "eka@example.com" },
  { nama: "Fajar", umur: 31, alamat: "Medan", email: "fajar@example.com" },
  { nama: "Gita", umur: 24, alamat: "Bali", email: "gita@example.com" },
  { nama: "Hana", umur: 29, alamat: "Makassar", email: "hana@example.com" },
  { nama: "Iwan", umur: 26, alamat: "Palembang", email: "iwan@example.com" },
  { nama: "Joko", umur: 33, alamat: "Manado", email: "joko@example.com" },
];

module.exports = data;
